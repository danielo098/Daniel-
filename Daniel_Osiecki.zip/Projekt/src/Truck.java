public class Truck extends Car implements  Kola {
    @Override
    public void iloscKol( int i) {
        System.out.println(i + " Ilosc kol (interfejs)");
    }
    public Truck(String model, int maxSpeed, int yearOfManufacture) {
        super(model, maxSpeed, yearOfManufacture);

        System.out.println("Model to "+ model + " Max predkość "+ maxSpeed + " Rok produkcji "+ yearOfManufacture );
        System.out.println("To jest klasa Truck");
        iloscKol(6);
        System.out.println(" ");
    }


}