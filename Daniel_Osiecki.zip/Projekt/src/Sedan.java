public class Sedan extends Car implements  Kola {
    @Override
    public void iloscKol( int i) {
        System.out.println(i + " Ilosc kol (interfejs)");
    }

    public Sedan(String model, int maxSpeed, int yearOfManufacture) {
        super(model, maxSpeed, yearOfManufacture);
        System.out.println("Model to " + model + " Max predkość " + maxSpeed + " Rok produkcji " + yearOfManufacture);
        System.out.println("To jest klasa Sedan");
        iloscKol(4);
        System.out.println(" ");
    }
}
