public class Car implements  Kola{
    private String model;
    private int maxSpeed;
    private int yearOfManufacture;



    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(int yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public Car() {

    }

    public Car(String model, int maxSpeed, int yearOfManufacture) {
        this.model = model;
        this.maxSpeed = maxSpeed;
        this.yearOfManufacture = yearOfManufacture;
    }



    public static void main(String[] args) {

        Car car = new Car();
        Truck truck = new Truck("Man", 90, 2019);
        Sedan sedan = new Sedan("Seat", 199, 2015);

        System.out.println(truck.getModel() + " Test motody get");
        truck.setMaxSpeed(250);
        System.out.println(truck.getMaxSpeed() + " Test motody get po set ");
        System.out.println("Wszystko działa :)");



    }
}