public interface Kola {
    default void iloscKol(int i){};
}
